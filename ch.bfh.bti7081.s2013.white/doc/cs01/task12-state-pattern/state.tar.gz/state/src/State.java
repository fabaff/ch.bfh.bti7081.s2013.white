public class State {
	public static void main(String[] args) {
		Door door = new Door(new DoorOpen());
		System.out.println("Door is open: " + door.action());
		
		door.setDoorState(new DoorClosed());
		System.out.println("Door in closed: " + door.action());

		door.setDoorState(new DoorLocked());
		System.out.println("Door is locked: " + door.action());
	}
}