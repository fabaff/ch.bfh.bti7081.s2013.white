public class State {
	public static void main(String[] args) {
		Door door = new Door(new DoorOpen());
		System.out.println("Door is open:");
		System.out.println("- " + door.open());
		System.out.println("- " + door.close());
		System.out.println("- " + door.lock());
		
		door.setDoorState(new DoorClosed());
		System.out.println("Door is closed:");
		System.out.println("- " + door.open());
		System.out.println("- " + door.close());
		System.out.println("- " + door.lock());

		door.setDoorState(new DoorLocked());
		System.out.println("Door is locked:");
		System.out.println("- " + door.open());
		System.out.println("- " + door.close());
		System.out.println("- " + door.lock());
	}
}