// State of the door
public interface DoorState {
	public String action();
}