// State of the door
public interface DoorState {
	public String close();
	public String lock();
	public String open();
}