//Concrete State: DoorLocked
public class DoorLocked implements DoorState {
	@Override
	public String open() {
		return "Can open the door. ";
	}

	@Override
	public String close() {
		return "Door is closed.";
	}

	@Override
	public String lock() {
		return "Door is alreay locked.";
	}
}