//Concrete State: DoorLocked
public class DoorLocked implements DoorState {
	@Override
	public String action() {
		return "Open the door";
	}
}