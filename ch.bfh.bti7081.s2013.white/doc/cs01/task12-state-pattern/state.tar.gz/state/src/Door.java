// Context
public class Door implements DoorState {
	DoorState doorState;

	public Door(DoorState doorState) {
		this.doorState = doorState;
	}

	public void setDoorState(DoorState doorState) {
		this.doorState = doorState;
	}
	
	@Override
	public String close() {
		return doorState.close();
	}

	@Override
	public String lock() {
		return doorState.lock();
	}

	@Override
	public String open() {
		return doorState.open();
	}
}