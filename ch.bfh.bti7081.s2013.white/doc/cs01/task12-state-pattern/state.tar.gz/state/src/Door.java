// Context
public class Door implements DoorState {
	DoorState doorState;

	public Door(DoorState doorState) {
		this.doorState = doorState;
	}

	public void setDoorState(DoorState doorState) {
		this.doorState = doorState;
	}
	
	@Override
	public String action() {
		return doorState.action();
	}
}