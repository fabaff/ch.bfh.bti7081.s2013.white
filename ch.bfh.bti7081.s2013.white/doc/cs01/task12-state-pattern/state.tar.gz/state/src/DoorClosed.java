//Concrete State: DoorClosed
public class DoorClosed implements DoorState {
	@Override
	public String action() {
		return "Lock the door";
	}
}