//Concrete State: DoorClosed
public class DoorClosed implements DoorState {
	@Override
	public String lock() {
		return "Lock the door.";
	}

	@Override
	public String close() {
		return "Door is already closed.";
	}

	@Override
	public String open() {
		return "Open the door.";
	}
}