//Concrete State: DoorOpen
public class DoorOpen implements DoorState {
	public String close() {
		return "Can close the door.";
	}

	@Override
	public String lock() {
		return "Can not lock the door.";
	}

	@Override
	public String open() {
		return "Door is already open.";
	}
}