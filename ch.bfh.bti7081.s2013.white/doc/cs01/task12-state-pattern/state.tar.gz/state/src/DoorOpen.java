//Concrete State: DoorOpen
public class DoorOpen implements DoorState {
	@Override
	public String action() {
		return "Close the door";
	}
}